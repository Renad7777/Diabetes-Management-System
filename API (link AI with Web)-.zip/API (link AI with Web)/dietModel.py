import warnings
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
from sklearn.metrics.pairwise import cosine_similarity
from imblearn.over_sampling import SMOTE
import joblib
import os

# Suppress warnings
warnings.filterwarnings('ignore')

class DietRecommendationModel:
    def __init__(self, data_path="diabetics_recommendation_cleaned4.csv"):
        """
        Initialize the DietRecommendationModel
        
        Args:
            data_path (str): Path to the dataset CSV file. Defaults to 'diabetics_recommendation_cleaned4.csv'
        """
        if not os.path.exists(data_path):
            raise FileNotFoundError(f"Dataset file not found at: {data_path}")
            
        self.data = pd.read_csv(data_path)
        self.meal_columns = ['Breakfast', 'Morning_Snack', 'Lunch', 'Afternoon_Snack', 'Dinner', 'Evening_Snack']
        self.numerical_cols = ['FastingBloodSugar', 'Systolic_BP', 'Diastolic_BP', 'LDL', 'HDL', 
                             'Triglycerides', 'BMI', 'Age', 'Cholesterol_Ratio', 'Sugar_BMI_Interaction']
        self.categorical_cols = ['Gender', 'BMI_Category', 'BP_Category', 'Age_Group']
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.model = None
        self._preprocess_data()
        self._train_model()

    def _preprocess_data(self):
        # Handle missing values
        self.data[self.meal_columns] = self.data[self.meal_columns].fillna('')
        self.data.fillna(self.data.mean(numeric_only=True), inplace=True)

        # Feature Engineering
        self.data['BMI_Category'] = pd.cut(self.data['BMI'], bins=[0, 18.5, 25, 30, 100], 
                                         labels=['Underweight', 'Normal', 'Overweight', 'Obese'])
        self.data['BP_Category'] = pd.cut(self.data['Systolic_BP'], bins=[0, 120, 140, 1000], 
                                        labels=['Normal', 'Prehypertension', 'Hypertension'])
        self.data['Cholesterol_Ratio'] = self.data['LDL'] / self.data['HDL']
        self.data['Age_Group'] = pd.cut(self.data['Age'], bins=[0, 30, 50, 100], 
                                       labels=['Young', 'Middle', 'Senior'])
        self.data['Sugar_BMI_Interaction'] = self.data['FastingBloodSugar'] * self.data['BMI']

        # Define target variable
        bins = [0, 100, 126, 1000]
        labels = ['Low', 'Normal', 'High']
        self.data['Sugar_Level'] = pd.cut(self.data['FastingBloodSugar'], bins=bins, labels=labels)

        # Encode target
        y = self.label_encoder.fit_transform(self.data['Sugar_Level'])

        # Prepare features
        X_numerical = self.scaler.fit_transform(self.data[self.numerical_cols])
        X_categorical = pd.get_dummies(self.data[self.categorical_cols], drop_first=True).values
        X = np.hstack((X_numerical, X_categorical))

        # Handle class imbalance
        smote = SMOTE(random_state=42)
        X, y = smote.fit_resample(X, y)

        # Train/Test split
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=0.25, random_state=42, stratify=y
        )

    def _train_model(self):
        self.model = LogisticRegression(
            solver='lbfgs',
            penalty='l2',
            C=1.0,
            max_iter=1000,
            multi_class='multinomial',
            random_state=42
        )
        self.model.fit(self.X_train, self.y_train)

    def predict_sugar_level(self, patient_data):
        """
        Predict sugar level for a new patient
        patient_data should be a dictionary containing all required features
        """
        patient_df = pd.DataFrame([patient_data])
        
        # Apply feature engineering
        patient_df['BMI_Category'] = pd.cut(patient_df['BMI'], bins=[0, 18.5, 25, 30, 100], 
                                          labels=['Underweight', 'Normal', 'Overweight', 'Obese'])
        patient_df['BP_Category'] = pd.cut(patient_df['Systolic_BP'], bins=[0, 120, 140, 1000], 
                                         labels=['Normal', 'Prehypertension', 'Hypertension'])
        patient_df['Cholesterol_Ratio'] = patient_df['LDL'] / patient_df['HDL']
        patient_df['Age_Group'] = pd.cut(patient_df['Age'], bins=[0, 30, 50, 100], 
                                        labels=['Young', 'Middle', 'Senior'])
        patient_df['Sugar_BMI_Interaction'] = patient_df['FastingBloodSugar'] * patient_df['BMI']

        # Transform features
        X_numerical_new = self.scaler.transform(patient_df[self.numerical_cols])
        X_categorical_new = pd.get_dummies(patient_df[self.categorical_cols], drop_first=True)
        train_categorical_cols = pd.get_dummies(self.data[self.categorical_cols], drop_first=True).columns
        X_categorical_new = X_categorical_new.reindex(columns=train_categorical_cols, fill_value=0).values
        X_new = np.hstack((X_numerical_new, X_categorical_new))

        # Predict
        y_pred_new = self.model.predict(X_new)
        return self.label_encoder.inverse_transform(y_pred_new)[0]

    def recommend_meals(self, patient_data, top_n=1):
        """
        Recommend meals based on patient data
        patient_data should be a dictionary containing all required features
        """
        predicted_sugar_level = self.predict_sugar_level(patient_data)
        patient_df = pd.DataFrame([patient_data])

        # Filter by sugar level first
        filtered_data = self.data[self.data['Sugar_Level'] == predicted_sugar_level].copy()
        
        if filtered_data.empty:
            return pd.DataFrame()

        # Apply health-based filtering with more flexible ranges
        bmi = patient_df['BMI'].iloc[0]
        triglycerides = patient_df['Triglycerides'].iloc[0]
        systolic_bp = patient_df['Systolic_BP'].iloc[0]
        diastolic_bp = patient_df['Diastolic_BP'].iloc[0]
        ldl = patient_df['LDL'].iloc[0]
        hdl = patient_df['HDL'].iloc[0]
        age = patient_df['Age'].iloc[0]
        gender = patient_df['Gender'].iloc[0]

        filtered_data = filtered_data[
            (filtered_data['BMI'].between(bmi - 10, bmi + 10)) &
            (filtered_data['LDL'].between(ldl - 40, ldl + 40)) &
            (filtered_data['HDL'].between(hdl - 20, hdl + 20)) &
            (filtered_data['Systolic_BP'].between(systolic_bp * 0.7, systolic_bp * 1.3)) &
            (filtered_data['Diastolic_BP'].between(diastolic_bp * 0.7, diastolic_bp * 1.3)) &
            (filtered_data['Triglycerides'].between(triglycerides * 0.5, triglycerides * 1.5)) &
            (filtered_data['Age'].between(age - 15, age + 15)) &
            (filtered_data['Gender'] == gender)
        ]

        if filtered_data.empty:
            return pd.DataFrame()

        # Calculate similarity scores with adjusted weights
        weights = np.array([3.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0])  # Increased weight for blood sugar
        X_train_numerical = self.scaler.transform(filtered_data[self.numerical_cols]) * weights
        X_new_numerical = self.scaler.transform(patient_df[self.numerical_cols]) * weights
        cosine_sim = cosine_similarity(X_new_numerical, X_train_numerical)
        cosine_sim_normalized = (cosine_sim + 1) / 2
        sim_scores = list(enumerate(cosine_sim_normalized[0]))
        sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)[:top_n]
        meal_indices = [i[0] for i in sim_scores]

        return_cols = self.meal_columns + ['Sugar_Level'] + self.numerical_cols + ['Gender']
        return filtered_data.iloc[meal_indices][return_cols]

    def get_meal_recommendations(self, patient_data):
        """
        Get meal recommendations in a format suitable for the web interface
        
        Args:
            patient_data (dict): Dictionary containing patient features
            
        Returns:
            tuple: (breakfast_meals, lunch_meals, dinner_meals) lists of recommended meals
        """
        # Calculate derived fields
        patient_data['BMI_Category'] = pd.cut([patient_data['BMI']], bins=[0, 18.5, 25, 30, 100], 
                                            labels=['Underweight', 'Normal', 'Overweight', 'Obese'])[0]
        patient_data['BP_Category'] = pd.cut([patient_data['Systolic_BP']], bins=[0, 120, 140, 1000], 
                                           labels=['Normal', 'Prehypertension', 'Hypertension'])[0]
        patient_data['Cholesterol_Ratio'] = patient_data['LDL'] / patient_data['HDL']
        patient_data['Age_Group'] = pd.cut([patient_data['Age']], bins=[0, 30, 50, 100], 
                                         labels=['Young', 'Middle', 'Senior'])[0]
        patient_data['Sugar_BMI_Interaction'] = patient_data['FastingBloodSugar'] * patient_data['BMI']
        
        recommendations = self.recommend_meals(patient_data, top_n=3)
        
        if recommendations.empty:
            return [], [], []
            
        # Extract meals for each time of day
        breakfast_meals = recommendations['Breakfast'].tolist()
        lunch_meals = recommendations['Lunch'].tolist()
        dinner_meals = recommendations['Dinner'].tolist()
        
        return breakfast_meals, lunch_meals, dinner_meals

    def save_model(self, model_path='logistic_model.joblib', scaler_path='scaler.joblib', 
                  encoder_path='label_encoder.joblib'):
        """Save the trained model and necessary components"""
        joblib.dump(self.model, model_path)
        joblib.dump(self.scaler, scaler_path)
        joblib.dump(self.label_encoder, encoder_path)

    def load_model(self, model_path='logistic_model.joblib', scaler_path='scaler.joblib', 
                  encoder_path='label_encoder.joblib'):
        """Load a previously trained model and components"""
        self.model = joblib.load(model_path)
        self.scaler = joblib.load(scaler_path)
        self.label_encoder = joblib.load(encoder_path)