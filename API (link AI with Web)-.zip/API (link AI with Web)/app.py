from flask import Flask, render_template, request, session, redirect, url_for
from dietModel import DietRecommendationModel
from exerciseModel import ExerciseRecommendationModel
import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics.pairwise import cosine_similarity
from imblearn.over_sampling import SMOTE

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Change this to a secure secret key

# Initialize models
diet_model = DietRecommendationModel()
exercise_model = ExerciseRecommendationModel()

# Load and preprocess data
data = pd.read_csv("C:/Users/DELL/Desktop/GlucoFlow/diabetics_recommendation_cleaned4.csv")

# Handle missing values
meal_columns = ['Breakfast', 'Morning_Snack', 'Lunch', 'Afternoon_Snack', 'Dinner', 'Evening_Snack']
data[meal_columns] = data[meal_columns].fillna('')
data.fillna(data.mean(numeric_only=True), inplace=True)

# Feature Engineering
data['BMI_Category'] = pd.cut(data['BMI'], bins=[0, 18.5, 25, 30, 100], 
                             labels=['Underweight', 'Normal', 'Overweight', 'Obese'])
data['BP_Category'] = pd.cut(data['Systolic_BP'], bins=[0, 120, 140, 1000], 
                            labels=['Normal', 'Prehypertension', 'Hypertension'])
data['Cholesterol_Ratio'] = data['LDL'] / data['HDL']
data['Age_Group'] = pd.cut(data['Age'], bins=[0, 30, 50, 100], 
                           labels=['Young', 'Middle', 'Senior'])
data['Sugar_BMI_Interaction'] = data['FastingBloodSugar'] * data['BMI']

# Define target variable
bins = [0, 100, 126, 1000]
labels = ['Low', 'Normal', 'High']
data['Sugar_Level'] = pd.cut(data['FastingBloodSugar'], bins=bins, labels=labels)

# Define numerical and categorical columns
numerical_cols = ['FastingBloodSugar', 'Systolic_BP', 'Diastolic_BP', 'LDL', 'HDL', 
                  'Triglycerides', 'BMI', 'Age', 'Cholesterol_Ratio', 'Sugar_BMI_Interaction']
categorical_cols = ['Gender', 'BMI_Category', 'BP_Category', 'Age_Group']

# Initialize preprocessing tools
scaler = StandardScaler()
label_encoder = LabelEncoder()

# Prepare features
X_numerical = scaler.fit_transform(data[numerical_cols])
X_categorical = pd.get_dummies(data[categorical_cols], drop_first=True).values
X = np.hstack((X_numerical, X_categorical))

# Prepare target
y = label_encoder.fit_transform(data['Sugar_Level'])

# Handle class imbalance
smote = SMOTE(random_state=42)
X, y = smote.fit_resample(X, y)

# Train model
model = LogisticRegression(
    solver='lbfgs',
    penalty='l2',
    C=1.0,
    max_iter=1000,
    multi_class='multinomial',
    random_state=42
)
model.fit(X, y)

def recommend_meals(input_df, predicted_sugar_level):
    # Find similar patients with the same sugar level
    filtered_data = data[data['Sugar_Level'] == predicted_sugar_level].copy()
    
    if filtered_data.empty:
        return None
    
    # Extract health features
    bmi = input_df['BMI'].iloc[0]
    triglycerides = input_df['Triglycerides'].iloc[0]
    systolic_bp = input_df['Systolic_BP'].iloc[0]
    diastolic_bp = input_df['Diastolic_BP'].iloc[0]
    ldl = input_df['LDL'].iloc[0]
    
    # Filter data based on health metrics
    filtered_data = filtered_data[
        (filtered_data['BMI'].between(bmi - 7, bmi + 7)) &
        (filtered_data['LDL'].between(ldl - 30, ldl + 30)) &
        (filtered_data['Systolic_BP'].between(systolic_bp * 0.75, systolic_bp * 1.25)) &
        (filtered_data['Diastolic_BP'].between(diastolic_bp * 0.75, diastolic_bp * 1.25)) &
        (filtered_data['Triglycerides'].between(triglycerides * 0.6, triglycerides * 1.4))
    ]
    
    if filtered_data.empty:
        return None
    
    # Calculate similarity scores
    weights = np.array([2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0])
    X_train_numerical = scaler.transform(filtered_data[numerical_cols]) * weights
    X_new_numerical = scaler.transform(input_df[numerical_cols]) * weights
    cosine_sim = cosine_similarity(X_new_numerical, X_train_numerical)
    cosine_sim_normalized = (cosine_sim + 1) / 2
    sim_scores = list(enumerate(cosine_sim_normalized[0]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)[:1]
    meal_indices = [i[0] for i in sim_scores]
    
    return filtered_data.iloc[meal_indices][meal_columns]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/service')
def service():
    return render_template('service.html')

@app.route('/diet-form', methods=['GET', 'POST'])
def diet_form():
    if request.method == 'POST':
        try:
            # Get input data from the form
            input_data = {
                'FastingBloodSugar': float(request.form['fastingBloodSugar']),
                'Systolic_BP': float(request.form['systolicBP']),
                'Diastolic_BP': float(request.form['diastolicBP']),
                'LDL': float(request.form['ldl']),
                'HDL': float(request.form['hdl']),
                'Triglycerides': float(request.form['triglycerides']),
                'Gender': int(request.form['gender']),
                'BMI': float(request.form['bmi']),
                'Age': float(request.form['age'])
            }
            
            # Preprocess input data
            input_df = pd.DataFrame([input_data])
            input_df['BMI_Category'] = pd.cut(input_df['BMI'], bins=[0, 18.5, 25, 30, 100], labels=['Underweight', 'Normal',
                                                                                                     'Overweight', 'Obese'])
            input_df['BP_Category'] = pd.cut(input_df['Systolic_BP'], bins=[0, 120, 140, 1000], labels=['Normal',
                                                                                                         'Prehypertension',
                                                                                                           'Hypertension'])
            input_df['Cholesterol_Ratio'] = input_df['LDL'] / input_df['HDL']
            input_df['Age_Group'] = pd.cut(input_df['Age'], bins=[0, 30, 50, 100], labels=['Young', 'Middle', 'Senior'])
            input_df['Sugar_BMI_Interaction'] = input_df['FastingBloodSugar'] * input_df['BMI']
            
            X_numerical = scaler.transform(input_df[numerical_cols])
            X_categorical = pd.get_dummies(input_df[categorical_cols], drop_first=True)
            train_categorical_cols = pd.get_dummies(data[categorical_cols], drop_first=True).columns
            X_categorical = X_categorical.reindex(columns=train_categorical_cols, fill_value=0).values
            X_input = np.hstack((X_numerical, X_categorical))
            
            # Predict sugar level
            prediction = model.predict(X_input)
            prediction_label = label_encoder.inverse_transform(prediction)[0]
            
            # Get meal recommendations
            meal_plan = recommend_meals(input_df, prediction_label)
            
            if meal_plan is not None:
                meal_plan_dict = meal_plan.iloc[0].to_dict()
            else:
                meal_plan_dict = {
                    'Breakfast': 'No specific recommendation available',
                    'Morning_Snack': 'No specific recommendation available',
                    'Lunch': 'No specific recommendation available',
                    'Afternoon_Snack': 'No specific recommendation available',
                    'Dinner': 'No specific recommendation available',
                    'Evening_Snack': 'No specific recommendation available'
                }
            
            return render_template('diet_page.html', 
                                prediction=prediction_label,
                                meal_plan=meal_plan_dict)
            
        except Exception as e:
            print(f"Error in diet_form: {str(e)}")
            return render_template('diet_form.html', error=str(e))
    
    return render_template('diet_form.html')

@app.route('/diet-page')
def diet_page():
    # Get meal recommendations from session
    breakfast_meals = session.get('breakfast_meals', [])
    lunch_meals = session.get('lunch_meals', [])
    dinner_meals = session.get('dinner_meals', [])
    
    return render_template('diet_page.html',
                         breakfast_meals=breakfast_meals,
                         lunch_meals=lunch_meals,
                         dinner_meals=dinner_meals)

@app.route('/chatbot')
def chatbot():
    return render_template('chatbot.html')

@app.route('/exercise-form', methods=['GET', 'POST'])
def exercise_form():
    if request.method == 'POST':
        try:
            print("Form submitted with data:", request.form)  # Debug log
            
            # Get form data and convert to proper types
            user_data = {
                'Gender': int(request.form['gender']),
                'Age': int(request.form['age']),
                'BMI': float(request.form['bmi']),
                'Smoker': int(request.form['smoker']),
                'HeartDiseaseorAttack': int(request.form['heartDisease']),
                'PhysActivity': int(request.form['physActivity']),
                'PhysHlth': int(request.form['physHlth']),
                'DiffWalk': int(request.form['diffWalk']),
                'AnyHealthcare': 1,  # Default value since it's not in the form
                'BMI_Category': request.form['bmiCategory'],
                'AgeGroup': request.form['ageGroup']
            }
            
            print("Processed user data:", user_data)  # Debug log
            
            # Convert user_data to DataFrame for model input
            user_df = pd.DataFrame([user_data])
            
            print("Created DataFrame:", user_df)  # Debug log
            
            # Get workout recommendations using the model's recommend_workouts_similarity function
            recommendations = exercise_model.recommend_workouts_similarity(user_df, exercise_model.X_scaled,
                                                                            exercise_model.data, exercise_model.workout_desc)
            
            print("Got recommendations:", recommendations)  # Debug log
            
            if recommendations.empty:
                print("No recommendations found")  # Debug log
                return render_template('exercise_form.html', 
                                    error="No workout recommendations found. Please try different inputs.")
            
            # Convert recommendations to a format suitable for display
            workout_recommendations = []
            for _, row in recommendations.iterrows():
                workout_recommendations.append({
                    'workout1': {'name': row['Workout1'], 'description': row['Desc1']},
                    'workout2': {'name': row['Workout2'], 'description': row['Desc2']},
                    'workout3': {'name': row['Workout3'], 'description': row['Desc3']}
                })
            
            print("Formatted recommendations:", workout_recommendations)  # Debug log
            
            return render_template('exercise_page.html',
                                workout_recommendations=workout_recommendations)
            
        except Exception as e:
            print(f"Error in exercise_form: {str(e)}")  # Debug log
            import traceback
            print("Full traceback:", traceback.format_exc())  # Print full error traceback
            return render_template('exercise_form.html', error=str(e))
    
    return render_template('exercise_form.html')

@app.route('/exercise-page')
def exercise_page():
    return render_template('exercise_page.html')

if __name__ == '__main__':
    app.run(debug=True) 